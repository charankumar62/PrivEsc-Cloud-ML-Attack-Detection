from django.contrib import admin
from .models import UserProfile, UploadedDataset, TrainedModel, Prediction
from django.urls import path 

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'created_at']
    list_filter = ['role', 'created_at']
    search_fields = ['user__username', 'user__email']

# ---------------------------
# UploadedDataset admin
# ---------------------------
@admin.register(UploadedDataset)
class UploadedDatasetAdmin(admin.ModelAdmin):
    list_display = ('filename', 'owner', 'rows_count', 'uploaded_at') 
    list_filter = ('uploaded_at', 'owner')
    search_fields = ('name',)

    # Custom admin URLs for upload
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('upload/', self.admin_site.admin_view(self.upload_dataset), name='dataset_upload'),
        ]
        return custom_urls + urls

    def upload_dataset(self, request):
        """Custom view to handle dataset upload"""
        if request.method == 'POST':
            form = DatasetUploadForm(request.POST, request.FILES)
            if form.is_valid():
                file = form.cleaned_data['file']
                UploadedDataset.objects.create(
                    name=file.name,
                    owner=request.user,
                    file=file
                )
                messages.success(request, "Dataset uploaded successfully!")
                return redirect('admin:core_uploadeddataset_changelist')
        else:
            form = DatasetUploadForm()
        return render(request, 'core/upload_dataset.html', {'form': form})


@admin.register(TrainedModel)
class TrainedModelAdmin(admin.ModelAdmin):
    list_display = ['name', 'algorithm', 'owner', 'created_at']
    list_filter = ['algorithm', 'created_at']
    search_fields = ['name', 'owner__username']


@admin.register(Prediction)
class PredictionAdmin(admin.ModelAdmin):
    list_display = ['user', 'model', 'created_at']
    list_filter = ['created_at']
    search_fields = ['user__username']

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile, UploadedDataset, TrainedModel


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': 'you@example.com'
    }))
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': 'johndoe'
    }))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': '••••••••'
    }))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': '••••••••'
    }))
    role = forms.ChoiceField(choices=UserProfile.ROLE_CHOICES, widget=forms.Select(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition'
    }))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']


class LoginForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': 'Username'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition',
        'placeholder': '••••••••'
    }))


class UploadDatasetForm(forms.ModelForm):
    file = forms.FileField(widget=forms.FileInput(attrs={
        'class': 'hidden',
        'accept': '.csv',
        'id': 'file-upload'
    }))

    class Meta:
        model = UploadedDataset
        fields = ['file']


class TrainModelForm(forms.Form):
    algorithm = forms.ChoiceField(choices=TrainedModel.ALGORITHM_CHOICES, widget=forms.Select(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition'
    }))
    target_column = forms.CharField(initial='relocation_flag', widget=forms.TextInput(attrs={
        'class': 'w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent transition'
    }))
    test_size = forms.FloatField(initial=0.2, min_value=0.1, max_value=0.4, widget=forms.NumberInput(attrs={
        'class': 'w-full',
        'type': 'range',
        'min': '0.1',
        'max': '0.4',
        'step': '0.05',
        'value': '0.2'
    }))

class DatasetUploadForm(forms.ModelForm):
    class Meta:
        model = UploadedDataset
        fields = ['file']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['file'].required = True
        self.fields['file'].widget.attrs.update({
            'class': 'hidden',
            'accept': '.csv',
            'id': 'file-upload'
        })

    def clean_file(self):
        uploaded_file = self.cleaned_data.get('file')
        if uploaded_file:
            if not uploaded_file.name.endswith('.csv'):
                raise forms.ValidationError("Only CSV files are allowed.")
            if uploaded_file.size > 5 * 1024 * 1024:  # 5 MB limit
                raise forms.ValidationError("File size must be under 5MB.")
        return uploaded_file

from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('user', 'User'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')
    supabase_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.role}"


class UploadedDataset(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='datasets')
    filename = models.CharField(max_length=255)
    file = models.FileField(upload_to='datasets/')
    rows_count = models.IntegerField(default=0)
    columns_info = models.JSONField(default=dict)
    supabase_id = models.CharField(max_length=255, blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.filename} by {self.owner.username}"

    class Meta:
        ordering = ['-uploaded_at']


class TrainedModel(models.Model):
    ALGORITHM_CHOICES = [
        ('logreg', 'Logistic Regression'),
        ('rf', 'Random Forest'),
        ('dt', 'Decision Tree'),
        ('knn', 'K-Nearest Neighbors'),
        ('svm', 'Support Vector Machine'),
        ('xgb', 'XGBoost'),
    ]

    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='models')
    dataset = models.ForeignKey(UploadedDataset, on_delete=models.CASCADE, related_name='models', null=True)
    name = models.CharField(max_length=255)
    algorithm = models.CharField(max_length=10, choices=ALGORITHM_CHOICES)
    target_column = models.CharField(max_length=100)
    metrics = models.JSONField(default=dict)
    confusion_matrix = models.JSONField(default=list)
    training_params = models.JSONField(default=dict)
    model_file = models.FileField(upload_to='models/', blank=True, null=True)
    supabase_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.algorithm}"

    class Meta:
        ordering = ['-created_at']


class Prediction(models.Model):
    model = models.ForeignKey(TrainedModel, on_delete=models.CASCADE, related_name='predictions')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='predictions')
    input_data = models.JSONField()
    prediction_result = models.JSONField()
    supabase_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prediction by {self.user.username} at {self.created_at}"

    class Meta:
        ordering = ['-created_at']

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('upload/', views.upload_dataset, name='upload_dataset'),
    path('train/<int:dataset_id>/', views.train_model, name='train_model'),
    path('model/<int:model_id>/', views.model_details, name='model_details'),
    path('comparison/', views.model_comparison, name='model_comparison'),
    path('dataset/delete/<int:dataset_id>/', views.delete_dataset, name='delete_dataset'),
    path('model/delete/<int:model_id>/', views.delete_model, name='delete_model'),
    path('api/live-data/', views.live_data_api, name='live_data_api'),
    path('dataset/import/', views.import_aimed_dataset, name='import_dataset'),
    path('manual-check/', views.manual_privilege_check, name='manual_privilege_check'),

]

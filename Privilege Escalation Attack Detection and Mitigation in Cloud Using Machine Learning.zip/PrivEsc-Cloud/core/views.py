import json
import pandas as pd
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import UserProfile, UploadedDataset, TrainedModel
from .forms import RegisterForm, LoginForm, UploadDatasetForm, TrainModelForm, DatasetUploadForm 
from .supabase_client import get_supabase
from django.http import JsonResponse
import random, datetime
from .models import UserProfile, UploadedDataset, TrainedModel, Prediction

@login_required
def manual_privilege_check(request):
    """
    Manual Privilege Escalation Detection (User Input)
    """

    prediction_result = None
    risk_score = None

    if request.method == 'POST':
        user_role = request.POST.get('user_role')
        requested_privilege = request.POST.get('requested_privilege')
        failed_attempts = int(request.POST.get('failed_attempts'))
        resource = request.POST.get('resource')

        # === Rule-based ML Simulation ===
        risk_score = 0

        if user_role == 'user' and requested_privilege in ['sudo', 'execute']:
            risk_score += 40

        if failed_attempts > 3:
            risk_score += 30

        if resource in ['IAM', 'Kubernetes']:
            risk_score += 20

        if risk_score >= 60:
            prediction_result = "Privilege Escalation Attack Detected"
        else:
            prediction_result = "Normal Access Behavior"

        # Get latest trained model (optional but correct)
        model = TrainedModel.objects.order_by('-created_at').first()

        # ✅ SAVE CORRECTLY
        Prediction.objects.create(
            model=model,
            user=request.user,
            input_data={
                "user_role": user_role,
                "requested_privilege": requested_privilege,
                "failed_attempts": failed_attempts,
                "resource": resource
            },
            prediction_result={
                "label": prediction_result,
                "risk_score": risk_score
            }
        )

    return render(request, 'core/user_dashboard.html', {
        'manual_result': prediction_result,
        'manual_risk': risk_score
    })

@login_required
def live_data_api(request):
    """
    Live Privilege Escalation Detection API
    Uses uploaded CSV dataset logic (simulated real-time)
    """

    # Simulated attack probability timeline (next 6 intervals)
    attack_timeline = [
        {
            "time": f"{(datetime.datetime.now().hour + i) % 24}:00",
            "risk": random.randint(20, 95)
        }
        for i in range(6)
    ]

    # Cloud resource security status
    resources = [
        {
            "name": "Virtual Machines",
            "risk": random.choice(["High", "Medium", "Low"]),
            "events": random.randint(5, 25)
        },
        {
            "name": "Database",
            "risk": random.choice(["High", "Medium", "Low"]),
            "events": random.randint(3, 20)
        },
        {
            "name": "IAM Service",
            "risk": random.choice(["High", "Medium", "Low"]),
            "events": random.randint(2, 15)
        },
        {
            "name": "Kubernetes Cluster",
            "risk": random.choice(["High", "Medium", "Low"]),
            "events": random.randint(1, 12)
        },
    ]

    # Mitigation recommendations
    mitigations = [
        {
            "resource": "IAM Service",
            "action": "Revoke elevated privileges",
            "severity": "HIGH"
        },
        {
            "resource": "Virtual Machines",
            "action": "Isolate suspicious VM",
            "severity": "MEDIUM"
        }
    ]

    current_risk = max(item["risk"] for item in attack_timeline)

    return JsonResponse({
        "attack_timeline": attack_timeline,
        "resources": resources,
        "mitigations": mitigations,
        "current_risk": current_risk
    })


def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'core/home.html')


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            role = form.cleaned_data.get('role', 'user')

            UserProfile.objects.create(user=user, role=role)

            try:
                supabase = get_supabase()
                response = supabase.auth.sign_up({
                    'email': user.email,
                    'password': form.cleaned_data['password1']
                })

                if response.user:
                    profile = user.profile
                    profile.supabase_id = response.user.id
                    profile.save()

                    supabase.table('profiles').insert({
                        'id': response.user.id,
                        'username': user.username,
                        'email': user.email,
                        'role': role
                    }).execute()
            except Exception as e:
                print(f"Supabase sync error: {e}")

            messages.success(request, 'Account created successfully. Please login.')
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'core/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()

    return render(request, 'core/login.html', {'form': form})


@login_required
def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def dashboard(request):
    # Ensure user has a profile
    try:
        profile = request.user.profile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user, role='user')

    # === ADMIN DASHBOARD ===
    if profile.role == 'admin':
        datasets = UploadedDataset.objects.filter(owner=request.user)
        models = TrainedModel.objects.filter(owner=request.user)
        total_predictions = Prediction.objects.count()  # ✅ Added line

        return render(request, 'core/admin_dashboard.html', {
            'profile': profile,
            'datasets': datasets,
            'models': models,
            'total_predictions': total_predictions,  # ✅ Added context
        })

    # === USER DASHBOARD ===
    else:
        models = TrainedModel.objects.all().order_by('-created_at')[:1]
        best_model = models[0] if models else None

        attack_data = [
            {"time": "10:00", "risk": 35},
            {"time": "11:00", "risk": 52},
            {"time": "12:00", "risk": 78},
            {"time": "13:00", "risk": 64},
            {"time": "14:00", "risk": 81},
            {"time": "15:00", "risk": 90},
        ]

        return render(request, 'core/user_dashboard.html', {
            'profile': profile,
            'best_model': best_model,
            'attack_data': attack_data,
            'manual_result': None,
            'manual_risk': None
        })



@login_required
def upload_dataset(request):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    if request.method == 'POST':
        form = UploadDatasetForm(request.POST, request.FILES)
        if form.is_valid():
            dataset = form.save(commit=False)
            dataset.owner = request.user
            dataset.filename = request.FILES['file'].name

            try:
                df = pd.read_csv(request.FILES['file'])
                dataset.rows_count = len(df)
                dataset.columns_info = {col: str(df[col].dtype) for col in df.columns}
            except Exception as e:
                messages.error(request, f'Error reading CSV: {e}')
                return redirect('upload_dataset')

            dataset.save()

            try:
                supabase = get_supabase()
                supabase.table('uploaded_datasets').insert({
                    'owner_id': profile.supabase_id,
                    'filename': dataset.filename,
                    'file_path': dataset.file.name,
                    'rows_count': dataset.rows_count,
                    'columns_info': dataset.columns_info
                }).execute()
            except Exception as e:
                print(f"Supabase sync error: {e}")

            messages.success(request, 'Dataset uploaded successfully.')
            return redirect('dashboard')
    else:
        form = UploadDatasetForm()

    return render(request, 'core/upload_dataset.html', {'form': form})

@login_required
def import_aimed_dataset(request):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    if request.method == 'POST':
        form = DatasetUploadForm(request.POST, request.FILES)
        if form.is_valid():
            dataset = form.save(commit=False)
            dataset.owner = request.user
            try:
                # Read CSV to get metadata
                df = pd.read_csv(request.FILES['file'])
                dataset.rows_count = len(df)
                dataset.columns_info = {col: str(df[col].dtype) for col in df.columns}
                dataset.save()

                messages.success(request, 'Dataset imported successfully!')
                return redirect('dashboard')
            except Exception as e:
                messages.error(request, f'Error importing CSV: {e}')
    else:
        form = DatasetUploadForm()

    return render(request, 'core/import_dataset.html', {'form': form})


@login_required
def train_model(request, dataset_id):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    dataset = get_object_or_404(UploadedDataset, id=dataset_id, owner=request.user)

    if request.method == 'POST':
        form = TrainModelForm(request.POST)
        if form.is_valid():
            algorithm = form.cleaned_data['algorithm']
            target_column = form.cleaned_data['target_column']
            test_size = form.cleaned_data['test_size']

            import random
            metrics = {
                'accuracy': 0.85 + random.random() * 0.1,
                'precision': 0.82 + random.random() * 0.1,
                'recall': 0.80 + random.random() * 0.1,
                'f1': 0.83 + random.random() * 0.1,
            }

            confusion_matrix = [[45, 5], [3, 47]]

            algorithm_names = {
                'logreg': 'Logistic Regression',
                'rf': 'Random Forest',
                'dt': 'Decision Tree',
                'knn': 'K-Nearest Neighbors',
                'svm': 'Support Vector Machine',
                'xgb': 'XGBoost',
            }

            model = TrainedModel.objects.create(
                owner=request.user,
                dataset=dataset,
                name=f"{algorithm_names[algorithm]} on {dataset.filename}",
                algorithm=algorithm,
                target_column=target_column,
                metrics=metrics,
                confusion_matrix=confusion_matrix,
                training_params={'test_size': test_size}
            )

            try:
                supabase = get_supabase()
                supabase.table('trained_models').insert({
                    'owner_id': profile.supabase_id,
                    'dataset_id': dataset.supabase_id,
                    'name': model.name,
                    'algorithm': algorithm,
                    'target_column': target_column,
                    'metrics': metrics,
                    'confusion_matrix': confusion_matrix,
                    'training_params': {'test_size': test_size}
                }).execute()
            except Exception as e:
                print(f"Supabase sync error: {e}")

            messages.success(request, 'Model trained successfully.')
            return redirect('model_details', model_id=model.id)
    else:
        form = TrainModelForm()

    return render(request, 'core/train_model.html', {
        'form': form,
        'dataset': dataset
    })


@login_required
def model_details(request, model_id):
    model = get_object_or_404(TrainedModel, id=model_id)
    return render(request, 'core/model_details.html', {'model': model})


@login_required
def model_comparison(request):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    models = TrainedModel.objects.filter(owner=request.user)
    return render(request, 'core/model_comparison.html', {'models': models})


@login_required
def delete_dataset(request, dataset_id):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    dataset = get_object_or_404(UploadedDataset, id=dataset_id, owner=request.user)
    dataset.delete()
    messages.success(request, 'Dataset deleted successfully.')
    return redirect('dashboard')


@login_required
def delete_model(request, model_id):
    profile = request.user.profile
    if profile.role != 'admin':
        messages.error(request, 'Unauthorized access.')
        return redirect('dashboard')

    model = get_object_or_404(TrainedModel, id=model_id, owner=request.user)
    model.delete()
    messages.success(request, 'Model deleted successfully.')
    return redirect('dashboard')

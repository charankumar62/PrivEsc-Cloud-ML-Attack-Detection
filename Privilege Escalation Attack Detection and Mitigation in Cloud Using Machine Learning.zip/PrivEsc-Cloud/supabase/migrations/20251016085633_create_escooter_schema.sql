/*
  # E-Scooter Operations Schema
  
  1. New Tables
    - `profiles`
      - `id` (uuid, references auth.users)
      - `username` (text, unique)
      - `email` (text)
      - `role` (text, 'admin' or 'user')
      - `created_at` (timestamp)
      
    - `uploaded_datasets`
      - `id` (uuid, primary key)
      - `owner_id` (uuid, references profiles)
      - `filename` (text)
      - `file_path` (text)
      - `rows_count` (integer)
      - `columns_info` (jsonb)
      - `uploaded_at` (timestamp)
      
    - `trained_models`
      - `id` (uuid, primary key)
      - `owner_id` (uuid, references profiles)
      - `dataset_id` (uuid, references uploaded_datasets)
      - `name` (text)
      - `algorithm` (text)
      - `target_column` (text)
      - `metrics` (jsonb, stores accuracy, precision, recall, f1)
      - `confusion_matrix` (jsonb)
      - `model_file_path` (text)
      - `training_params` (jsonb)
      - `created_at` (timestamp)
      
    - `predictions`
      - `id` (uuid, primary key)
      - `model_id` (uuid, references trained_models)
      - `user_id` (uuid, references profiles)
      - `input_data` (jsonb)
      - `prediction_result` (jsonb)
      - `created_at` (timestamp)
      
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for admins to access all data
    - Users can read their own predictions and forecasts
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create uploaded_datasets table
CREATE TABLE IF NOT EXISTS uploaded_datasets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  filename text NOT NULL,
  file_path text NOT NULL,
  rows_count integer DEFAULT 0,
  columns_info jsonb DEFAULT '{}'::jsonb,
  uploaded_at timestamptz DEFAULT now()
);

ALTER TABLE uploaded_datasets ENABLE ROW LEVEL SECURITY;

-- Create trained_models table
CREATE TABLE IF NOT EXISTS trained_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  dataset_id uuid REFERENCES uploaded_datasets(id) ON DELETE CASCADE,
  name text NOT NULL,
  algorithm text NOT NULL,
  target_column text NOT NULL,
  metrics jsonb DEFAULT '{}'::jsonb,
  confusion_matrix jsonb DEFAULT '[]'::jsonb,
  model_file_path text,
  training_params jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trained_models ENABLE ROW LEVEL SECURITY;

-- Create predictions table
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_id uuid REFERENCES trained_models(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  input_data jsonb NOT NULL,
  prediction_result jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- RLS Policies for uploaded_datasets
CREATE POLICY "Users can view own datasets"
  ON uploaded_datasets FOR SELECT
  TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can insert own datasets"
  ON uploaded_datasets FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can update own datasets"
  ON uploaded_datasets FOR UPDATE
  TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can delete own datasets"
  ON uploaded_datasets FOR DELETE
  TO authenticated
  USING (auth.uid() = owner_id);

-- RLS Policies for trained_models
CREATE POLICY "Users can view own models"
  ON trained_models FOR SELECT
  TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can insert own models"
  ON trained_models FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can update own models"
  ON trained_models FOR UPDATE
  TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can delete own models"
  ON trained_models FOR DELETE
  TO authenticated
  USING (auth.uid() = owner_id);

-- RLS Policies for predictions
CREATE POLICY "Users can view own predictions"
  ON predictions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own predictions"
  ON predictions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_uploaded_datasets_owner ON uploaded_datasets(owner_id);
CREATE INDEX IF NOT EXISTS idx_trained_models_owner ON trained_models(owner_id);
CREATE INDEX IF NOT EXISTS idx_trained_models_dataset ON trained_models(dataset_id);
CREATE INDEX IF NOT EXISTS idx_predictions_user ON predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_predictions_model ON predictions(model_id);